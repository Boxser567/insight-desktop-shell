# Desktop Canvas Plugin

`@insight-ai/desktop-canvas-plugin` 将成熟 Web 画布接入 Harness。Agent 通过插件常驻 Client 服务操作原生 Store、保存队列与生成监控，不需要打开画布；打开后的 iframe 复用同一业务上下文。Core 与后端业务代码不改。

[架构与模块边界](docs/architecture.md) · [通信契约](docs/protocol.md) · [开发与验证](docs/development.md) · [人工验收](docs/acceptance.md) · [源码来源](docs/porting.md)

当前整合版本为 `0.3.0-alpha.31`，包含已完成的批量操作、13个工具、多类型素材导入、TTS与音频播放/预览修复。版本范围、分支保留与验证限制见[整合记录](docs/verification/2026-10-20-main-integration.md)。

## 指引中心

[desktop-canvas-workflow](guidance/desktop-canvas-workflow/SKILL.md) 随插件注册到官方Skill目录。Agent按需加载入口和章节；用户直接说“用刚才生成的图做一张海报，放到画布里”，无需额外@Skill。manifest维护简短发现描述/入口提示，Markdown维护工作流、追问与交付规则；工具只维护原子操作及状态事实。更改指引后构建新包并重启Harness，不复制到用户全局Skill目录，也不自动热更新。

素材支持UTF-8 TXT/Markdown、PNG/JPEG/GIF/WebP、MP4/MOV/WebM、MP3/WAV/M4A/AAC。图片/音频小于20MiB，视频小于200MiB且最多300秒；正文最多32768字符/128KiB。媒体按真实内容验证，视频原音轨保留，导入不转码、不触发模型生成。

来源包括当前可见用户附件、同会话media-generator真实成功回执、授权画布节点，以及当前会话工作区文件。canvas_assets只读返回统一assets[]；生成素材使用不透明assetRef，兼容已有图片引用，不接受Agent提供的任意URL。工作区文件经公开FileSystem校验边界并创建私有内容快照，不直接读取Agent给出的Host路径。大媒体流式读取/上传，不经过桥的JSON。上传、保存、素材登记分别返回结果；未知结果不自动重放。

## 使用与边界

插件兼容目标为 Core `0.2.1-alpha.1` / Cordis `4.0.5-alpha.1`。安装构建的 `.tgz` 后重启 Harness。画布地址为 `dsh-resource://canvas/<十进制ID>`；成果卡片提供正式打开入口，插件没有测试用 ID 输入控件。

| Agent 工具 | 职责 |
|---|---|
| `canvas_create` | 创建并准备空画布 |
| `canvas_get` | 读取画布摘要、节点详情或真实图关系 |
| `canvas_node_edit` | 按 `ops[]` 顺序新增、修改、删除普通节点及配置图片/视频/TTS模型、音色和高级参数 |
| `canvas_edges` | 按 `ops[]` 顺序新增、删除、改接连线和排序输入 |
| `canvas_models` | 查询当前账号图片/视频/TTS模型与参数；按需分页查询公共/我的音色及详情 |
| `canvas_assets` | 发现当前对话文本/图片/音视频附件及可确认的远端图片/音视频 |
| `canvas_asset_import` | 导入四类附件、对话产物、已授权节点内容或工作区文件 |
| `canvas_run` | 运行依赖就绪的普通图片/视频/TTS节点，每批原生工作流共用一个 Core Job；容量满时返回续跑位置 |
| `canvas_open` | 打开本对话画布，可定位节点，不修改或生成 |
| `canvas_list` | 当前账号画布名称检索与分页 |
| `canvas_capabilities` | 当前账号专用处理权限、模型参数与排版模式 |
| `canvas_layout` | 指定节点横排、竖排、宫格；原生规则可能扩展同组成员 |
| `canvas_process` | 单份素材高清图片/视频、图像分层、自动抠图；保留来源和关联结果 |


公开工具目录、入参和文案以 [canvas-tool-contracts.ts](src/shared/canvas-tool-contracts.ts) 为准；运行时校验以共享 DTO/parser 和原生业务为准。不提供原始 Store 写入、任意 URL 转发或模型参数中的授权开关。专用处理由canvas_process创建所需原生处理与结果节点；不开放任意工具节点或原始Store写入。模板和整图执行仍不在公开范围。

每次修改使用最新 `confirmed` 版本，只有 `saved` 才表示持久化成功。`refresh:true` 是显式权威重载，可能重载可见画布；普通写前/后读取使用 `refresh:false`。未知保存/执行结果不得自动重复提交。节点延展、输入关系和默认放置复用原生规则；不自动重排已有画布。

本次批量接口迁移：节点/边操作使用 `ops[]`，生成使用 `nodeIds[]`（单目标也使用数组）；不再接受旧 `action` / 单个 `nodeId` 入参。更新后重启 Harness 并新建对话，以当前工具目录为准；已交付 alpha.20 归档保持不变。

生成只提交指定节点，上游须已有产物；输入未就绪的上下游不能同批运行。`submitted` 是接受任务，不是生成完成；取消 Jobs 跟踪不等于取消云端生成。一个真实需求累计超过30张图片或6条视频时，由官方用户问题服务确认。完整退出客户端后，不承诺自动恢复未完成生成或跨进程 exactly-once。

TTS复用原生模型配置、音色库、费用/容量、保存队列和任务监控。高级参数按实际选项、范围与步长校验；音色保存及提交前通过当前账号详情确认。已有个人音色可选，是否允许新建定制音色另行区分；未声明的模型/平台映射不推断。当前不开放音乐/翻唱运行或音色克隆。

## 成果来源与展示

只有从可信本次原生生成状态登记、持久化的画布产物才显示成果卡片；普通附件、非画布素材及没有来源记录的历史素材不会猜测补绑。原始 Session、Turn、根调用、画布、节点和任务身份由 Host 捕获，不由模型填写。来源存于官方 Storage Domain，不扩展 Core Session 格式。

卡片使用真实画布标题、最多四项方形等比预览与唯一打开按钮。外框包裹内容；宽时四项一排，窄时2+2，三项2+1。单项真实产物打开并定位节点，多项只打开画布；展示上限不改变这个判断。普通文件卡片和系统打开菜单保持原样。

音频成果复用同一可信来源与卡片，提供原生播放控件，不自动播放；普通音频附件/导入素材不自动产生画布成果卡片。

重启可恢复已确认的来源；fork 不自动继承父会话来源。标题或临时素材 URL 读取失败不触发再次生成，仍提供打开入口。用户已完成核心能力的初步人工验收，首版审核不等于全部异常路径或未来 Core 版本均已验证。

## 本地开发

```sh
npm ci
pnpm --dir canvas-app install --frozen-lockfile
npm test
npm run typecheck
npm run pack:plugin
npm run verify:isolated
```

Node.js `>=22.12.0`，pnpm `11.7.0`。根包和 `canvas-app` 分别锁定依赖；不自动升级复制的业务依赖。隔离验证需要同级 Shell 已构建运行时，只操作专属测试目录，不使用真实登录账号。更多要求见 [开发与验证](docs/development.md)。

## 专用处理与导航

五个新增工具与四项专用处理统一维护在现有Skill。处理使用常驻Context、严格保存、现有external-task接口和独立结果监控，关闭视图不停止；原生高清/分层组件让出正在由服务监控的同一任务，手动操作保留。生成与处理按真实会话共享并发与数量确认，分层按实际请求层数计图；未知提交不自动重做。

自动抠图固定目标由Host服务环境选择：测试https://test-api-upload.idealead.com，生产https://api-upload.idealead.com。不接受Agent提供目标URL；请求来源须与当前可访问画布已保存图片一致。自动抠图的本地operationId与云端taskId明确区分，结果身份和真实子节点登记到原有成果Domain。原素材保留，多产物选择非当前项时建立明确参考快照。分层交付为多张图层图片，不承诺PSD。

只问画布ID时，默认回复“当前画布 ID：[103334](dsh-resource://canvas/103334)。”并替换为真实ID。当前Core会过滤该URI的普通Markdown链接，插件在公开assistant-step插槽中仅适配这种简洁短答，显示真实可点击ID；不改Session原文或接管其他Markdown。普通完整成果仍用原生插件成果卡片和canvas_open。

专用处理完整退出客户端后不承诺自动恢复监控；保存/提交结果未知需核对原任务。视频高清处理已有画布视频，外部视频先按素材导入流程加入画布。自动化与隔离验证使用合成响应，不构成真实账号处理质量或服务可用性的证明。

## 创建画布入口

创建画布的真实成功回执会在对话底部显示独立的“画布 ID：数字”链接，空画布也可打开。入口从公开Chat工具投影读取根调用及PTC子调用，兼容已有历史回放，不依赖Agent的回复句式、是否打印ID或Markdown协议支持。仅点击时打开侧栏；正文、复制和素材成果卡片保持原样。

创建已成功但runtime:not_ready仍保留入口；失败、create_unknown或身份不匹配不补造入口。同轮同画布去重，多画布分别显示；未加载的历史调用需加载后才恢复，不扫描正文猜测ID。旧版ID短答适配仍是可选的展示增强。

节点音频与预览继续使用原生WaveSurfer，经受保护的同源资源通道读取；预览保留节点地址并短时复用已读音频。临时读取失败最多自动重试一次，权限/来源拒绝与解码错误不自动重试。详见[音频修复及复验](docs/verification/2026-10-20-canvas-audio-preview.md)。
