/**
 * Validate the native chart contract all the way to something the renderer
 * can actually draw. The shared guard still owns field/type validation; this
 * layer adds renderer-specific invariants that would otherwise produce an
 * empty line/donut chart or a grouped-bars shell with no points.
 */
export declare function validateRenderableChartSemantics(value: unknown): string[];
